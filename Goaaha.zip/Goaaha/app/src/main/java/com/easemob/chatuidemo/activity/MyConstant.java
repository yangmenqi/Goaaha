package com.easemob.chatuidemo.activity;

import android.os.Environment;

/**
 * Created by kelvin on 16/4/20.
 */
public class MyConstant {
    public static String PhotoDir = Environment.getExternalStorageDirectory() + "/PhotoDemo/image/";
}
